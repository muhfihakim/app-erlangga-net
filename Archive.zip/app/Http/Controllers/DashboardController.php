<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use Illuminate\Http\Request;
use App\Models\PreOrder; // Pastikan Anda mengimpor Model PreOrder Anda
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon; // Digunakan untuk manipulasi tanggal dan waktu

class DashboardController extends Controller
{
    public function index()
    {
        $user = Auth::user();

        // 1. Definisikan Periode Waktu
        $startOfMonth = Carbon::now()->startOfMonth();
        $endOfMonth = Carbon::now()->endOfMonth();
        $startOfPreviousMonth = Carbon::now()->subMonth()->startOfMonth();
        $endOfPreviousMonth = Carbon::now()->subMonth()->endOfMonth();

        // 2. Hitung Base Data (PO Masuk)
        // $totalPoThisMonth = PreOrder::whereBetween('created_at', [$startOfMonth, $endOfMonth])->count();
        // $totalPoPreviousMonth = PreOrder::whereBetween('created_at', [$startOfPreviousMonth, $endOfPreviousMonth])->count();
        $poQueryThisMonth = PreOrder::whereBetween('created_at', [$startOfMonth, $endOfMonth]);
        $poQueryPreviousMonth = PreOrder::whereBetween('created_at', [$startOfPreviousMonth, $endOfPreviousMonth]);

        if ($user->jabatan === 'Sales') {
            // Filter hanya PO milik sales yang sedang login
            $poQueryThisMonth->where('id_sales', $user->id);
            $poQueryPreviousMonth->where('id_sales', $user->id);
        }

        $totalPoThisMonth = $poQueryThisMonth->count();
        $totalPoPreviousMonth = $poQueryPreviousMonth->count();


        // 3. Hitung Data Aktivasi & Pending
        $activatedPOIds = Customer::pluck('pre_order_id');
        // $totalAktivasiThisMonth = Customer::whereBetween('created_at', [$startOfMonth, $endOfMonth])->count();
        // $totalPendingThisMonth = PreOrder::whereBetween('created_at', [$startOfMonth, $endOfMonth])
        //     ->whereNotIn('id', $activatedPOIds)
        //     ->count();
        $totalAktivasiThisMonth = Customer::whereBetween('created_at', [$startOfMonth, $endOfMonth]);
        $totalPendingThisMonthQuery = PreOrder::whereBetween('created_at', [$startOfMonth, $endOfMonth])
            ->whereNotIn('id', $activatedPOIds);

        if ($user->jabatan === 'Sales') {
            $totalAktivasiThisMonth->whereHas('preorder', function ($query) use ($user) {
                $query->where('id_sales', $user->id);
            });
            $totalPendingThisMonthQuery->where('id_sales', $user->id);
        }

        $totalAktivasiThisMonth = $totalAktivasiThisMonth->count();
        $totalPendingThisMonth = $totalPendingThisMonthQuery->count();


        // 4. Hitung Persentase Perubahan (PO)
        $percentageChange = 0;
        if ($totalPoPreviousMonth > 0) {
            $percentageChange = (($totalPoThisMonth - $totalPoPreviousMonth) / $totalPoPreviousMonth) * 100;
        } elseif ($totalPoThisMonth > 0) {
            $percentageChange = 100;
        }

        // 5. Logika Khusus Teknisi: Tugas Delegasi
        $delegatedTasks = collect();

        if ($user->jabatan === 'Teknisi') {
            $delegatedTasks = PreOrder::whereNotIn('id', $activatedPOIds)
                // HANYA AMBIL PO YANG BENAR-BENAR DIDELEGASIKAN KEPADA USER INI
                ->where('id_teknisi_delegasi', $user->id)
                ->whereNotNull('delegated_at')
                ->orderBy('delegated_at', 'asc')
                ->get()
                ->map(function ($po) {
                    $po->deadline_date = null;
                    $po->status_display = 'AKTIF';
                    $po->bg_color = 'bg-info';

                    if ($po->delegated_at) {
                        $delegationDate = Carbon::parse($po->delegated_at);
                        $deadline = $delegationDate->copy()->addDays(3);
                        $now = Carbon::now();

                        // Simpan deadline lengkap untuk tampilan
                        $po->deadline_date = $deadline->format('d-m-Y H:i');

                        if ($now->greaterThan($deadline)) {
                            $po->status_display = 'EXPIRED';
                            $po->bg_color = 'bg-danger';
                        } elseif ($now->diffInHours($deadline) <= 24) {
                            $po->status_display = 'SEGERA EXPIRED';
                            $po->bg_color = 'bg-warning text-dark';
                        }
                    }
                    return $po;
                });
        }

        // 6. Kirim data ke view
        return view('dashboard', compact(
            'totalPoThisMonth',
            'totalPoPreviousMonth',
            'percentageChange',
            'totalAktivasiThisMonth',
            'totalPendingThisMonth',
            'delegatedTasks',
            'user'
        ));
    }
}
