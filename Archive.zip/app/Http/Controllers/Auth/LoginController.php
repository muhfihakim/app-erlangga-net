<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    /**
     * Tampilkan halaman login.
     */
    public function showLoginForm()
    {
        return view('auth.login');
    }

    /**
     * Handle proses login.
     */
    // public function login(Request $request)
    // {
    //     $credentials = $request->only('email', 'password');

    //     if (Auth::attempt($credentials)) {
    //         // Login berhasil
    //         return redirect()->intended('/dashboard');
    //     }

    //     // Login gagal
    //     return back()->withErrors([
    //         'email' => 'Email atau password salah.',
    //     ]);
    // }

    public function login(Request $request)
    {
        $credentials = $request->only('email', 'password');

        if (Auth::attempt($credentials)) {
            $user = Auth::user();

            // Jika user belum punya 2FA secret → arahkan ke halaman setup
            if (is_null($user->google2fa_secret)) {
                return redirect()->route('2fa.setup');
            }

            // Jika sudah punya secret → logout dulu dan arahkan ke verifikasi kode
            session(['2fa:user:id' => $user->id]);
            Auth::logout();

            return redirect()->route('2fa.verify');
        }

        return back()->withErrors([
            'email' => 'Email atau password salah.',
        ]);
    }



    /**
     * Handle proses logout.
     */
    public function logout(Request $request)
    {
        Auth::logout();

        $request->session()->invalidate();

        $request->session()->regenerateToken();

        $request->session()->forget('2fa_verified');

        return redirect('/login');
    }
}
