<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\PreOrder;
use App\Models\Customer;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\ValidationException;

class CustomerController extends Controller
{
    // Tampilkan daftar Pre-Order yang SIAP diaktivasi
    // public function index()
    // {
    //     if (auth()->user()->jabatan !== 'Teknisi' && auth()->user()->jabatan !== 'Administrator') {
    //         abort(403, 'Akses ditolak.');
    //     }

    //     // Ambil semua ID PO yang SUDAH diaktivasi
    //     $activatedPOIds = Customer::pluck('pre_order_id');

    //     // Ambil semua PO yang BELUM diaktifkan
    //     $preOrders = PreOrder::whereNotIn('id', $activatedPOIds)->get();

    //     // Ambil daftar Sales untuk dropdown di modal (role: Sales)
    //     $sales = User::where('jabatan', 'Sales')->orderBy('nama_lengkap')->get();

    //     return view('customers.index', compact('preOrders', 'sales'));
    // }


    public function index()
    {
        if (auth()->user()->jabatan !== 'Teknisi' && auth()->user()->jabatan !== 'Administrator') {
            abort(403, 'Akses ditolak.');
        }

        $user = auth()->user();
        $activatedPOIds = Customer::pluck('pre_order_id');

        // --- QUERY DASAR: PO yang BELUM diaktivasi ---
        $baseQuery = PreOrder::whereNotIn('id', $activatedPOIds);

        // --- FILTER KHUSUS TEKNISI ---
        if ($user->jabatan === 'Teknisi') {
            // Ambil PO yang ditugaskan secara KHUSUS kepada Teknisi INI
            $delegatedTasks = $baseQuery->clone()
                ->where('id_teknisi_delegasi', $user->id)
                ->whereNotNull('delegated_at')
                ->orderBy('delegated_at', 'asc')
                ->get()
                ->map(function ($po) {
                    // Logika Status Locked dan Deadline (Sama seperti sebelumnya)
                    $po->is_locked = false;
                    $po->deadline_status = 'AKTIF';
                    $po->bg_color = 'bg-info';

                    if ($po->delegated_at) {
                        $delegationDate = Carbon::parse($po->delegated_at);
                        $deadline = $delegationDate->copy()->addDays(3);
                        $now = Carbon::now();

                        $po->deadline_date = $deadline->format('d-m-Y H:i');

                        if ($now->greaterThan($deadline)) {
                            $po->deadline_status = 'EXPIRED';
                            $po->is_locked = true;
                        } elseif ($now->diffInHours($deadline) <= 24) {
                            $po->deadline_status = 'SEGERA';
                        }
                    }
                    return $po;
                });

            // Ambil PO UMUM (yang belum ditugaskan siapa-siapa)
            $generalTasks = $baseQuery->clone()
                ->whereNull('id_teknisi_delegasi') // Hanya yang belum ditugaskan
                ->orderBy('created_at', 'asc')
                ->get();

            // Teknisi hanya melihat dua koleksi terpisah ini
            return view('customers.index', compact('delegatedTasks', 'generalTasks'));
        } else {
            // --- AKSES GLOBAL UNTUK ADMINISTRATOR ---
            // Administrator melihat SEMUA PO yang siap aktivasi (Global View)
            $allPreOrders = $baseQuery->orderBy('created_at', 'asc')->get()->map(function ($po) {
                // Tambahkan status delegasi untuk Admin
                $po->delegated_to = $po->id_teknisi_delegasi ? (User::find($po->id_teknisi_delegasi)->nama_lengkap ?? 'Unknown') : 'Belum Ditunjuk';
                return $po;
            });

            // Kirim semua PO ke view dalam satu variabel tunggal
            return view('customers.index', compact('allPreOrders'));
        }
    }

    // Fungsi ACTIVE LIST: Menampilkan daftar Pelanggan Aktif
    public function activeList()
    {
        // Cek otentikasi tetap diperlukan
        if (!auth()->check()) {
            return redirect('/login')->with('error', 'Silakan login untuk mengakses data pelanggan.');
        }

        $user = auth()->user();
        $query = Customer::query();

        // Logika Akses: Semua role bisa masuk, tetapi Sales difilter
        if ($user->jabatan === 'Sales') {
            // Sales: Hanya melihat pelanggan yang sesuai dengan ID Sales mereka.
            $query->where('id_sales', $user->id);
        }
        // Administrator dan Teknisi akan melewati kondisi ini dan melihat semua data (no filter)

        $customers = $query->get();

        return view('customers.active_list', compact('customers'));
    }

    // Proses Aktivasi menjadi Customer
    public function store(Request $request)
    {
        // Hapus dd($request->all()); agar kode bisa dilanjutkan.

        if (auth()->user()->jabatan !== 'Teknisi' && auth()->user()->jabatan !== 'Administrator') {
            abort(403, 'Akses ditolak.');
        }

        $fotoPetugasPath = null;
        $fotoTerpasangPath = null;
        $fotoSpeedtestPath = null;

        try {
            // Validasi data input
            $validatedData = $request->validate([
                'pre_order_id' => 'required|exists:pre_orders,id|unique:customers,pre_order_id',
                'id_sales' => 'required|exists:users,id',
                'id_teknisi' => 'required|exists:users,id',
                'pppoe_username' => 'required|string|max:255|unique:customers,pppoe_username',
                'pppoe_password' => 'required|string|min:1',
                'id_pelanggan' => 'required|string|max:255|unique:customers,id_pelanggan',
                'jenis_modem' => 'required|in:EPON,GPON',
                'sn_perangkat' => 'required|string|max:255',
                'pembayaran' => 'required|in:Cash,Transfer,Aplikasi',
                'partner' => 'nullable|string|max:255',
                'keterangan' => 'nullable|string',
                'foto_petugas' => 'required|image|max:2048',
                'foto_terpasang' => 'required|image|max:2048',
                'foto_speedtest' => 'required|image|max:2048',
            ]);

            // Ambil data PO untuk diisi otomatis
            $po = PreOrder::findOrFail($request->pre_order_id);

            // Handle Unggahan Foto
            $fotoPetugasPath = $request->file('foto_petugas')->store('customers/foto_petugas', 'public');
            $fotoTerpasangPath = $request->file('foto_terpasang')->store('customers/foto_terpasang', 'public');
            $fotoSpeedtestPath = $request->file('foto_speedtest')->store('customers/foto_speedtest', 'public');

            // Simpan data Customer
            Customer::create([
                'pre_order_id' => $po->id,
                'id_sales' => $po->id_sales,
                'id_teknisi' => $validatedData['id_teknisi'],
                'nama_lengkap' => $po->nama_lengkap,
                'alamat_lengkap' => $po->alamat_lengkap,
                'no_whatsapp' => $po->no_whatsapp,
                'paket_internet' => $po->paket_internet,

                // Data Teknis
                'id_pelanggan' => $validatedData['id_pelanggan'],
                'pppoe_username' => $validatedData['pppoe_username'],
                'pppoe_password' => $validatedData['pppoe_password'],
                'jenis_modem' => $validatedData['jenis_modem'],
                'sn_perangkat' => $validatedData['sn_perangkat'],

                // Data Administrasi
                'pembayaran' => $validatedData['pembayaran'],
                'partner' => $validatedData['partner'],
                'keterangan' => $validatedData['keterangan'],

                // Path Foto
                'foto_petugas' => $fotoPetugasPath,
                'foto_terpasang' => $fotoTerpasangPath,
                'foto_speedtest' => $fotoSpeedtestPath,
            ]);

            return redirect()->route('customers.index')->with('success', 'Aktivasi pelanggan berhasil!');
        } catch (ValidationException $e) {
            // Tampilkan pesan error validasi di frontend
            return redirect()->back()->withInput()->withErrors($e->validator);
        } catch (\Exception $e) {
            // === BAGIAN KRUSIAL UNTUK DEBUGGING ===
            // Hapus file yang mungkin sudah terunggah sebelum kegagalan penyimpanan DB
            if (isset($fotoPetugasPath) && Storage::disk('public')->exists($fotoPetugasPath)) Storage::disk('public')->delete($fotoPetugasPath);
            if (isset($fotoTerpasangPath) && Storage::disk('public')->exists($fotoTerpasangPath)) Storage::disk('public')->delete($fotoTerpasangPath);
            if (isset($fotoSpeedtestPath) && Storage::disk('public')->exists($fotoSpeedtestPath)) Storage::disk('public')->delete($fotoSpeedtestPath);

            // Tampilkan pesan error lengkap, termasuk baris kode kegagalan
            $errorMessage = 'Gagal Aktivasi: ' . $e->getMessage() . ' | Line: ' . $e->getLine();

            return redirect()->back()->with('error', $errorMessage);
        }
    }
}
