<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use PragmaRX\Google2FA\Google2FA;
use BaconQrCode\Writer;
use BaconQrCode\Renderer\ImageRenderer;
use BaconQrCode\Renderer\Image\SvgImageBackEnd;
use BaconQrCode\Renderer\RendererStyle\RendererStyle;


class AccountController extends Controller
{
    /**
     * Tampilkan daftar akun pengguna.
     * Hanya dapat diakses oleh Administrator.
     */
    public function index()
    {
        // Pastikan hanya Administrator yang bisa mengakses
        if (auth()->user()->jabatan !== 'Administrator') {
            abort(403, 'Akses ditolak.');
        }

        $users = User::all();
        return view('account-manage', compact('users'));
    }

    public function store(Request $request)
    {
        // Pastikan hanya Administrator yang bisa mengakses
        if (auth()->user()->jabatan !== 'Administrator') {
            abort(403, 'Akses ditolak.');
        }

        $request->validate([
            'nama_lengkap' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:8',
            'nik' => 'nullable|string|max:255',
            'alamat' => 'nullable|string',
            'jenis_kelamin' => 'nullable|string|max:255',
            'tanggal_lahir' => 'nullable|date',
            'jabatan' => 'required|in:Administrator,Sales,Teknisi',
        ]);

        User::create([
            'nama_lengkap' => $request->nama_lengkap,
            'email' => $request->email,
            'password' => Hash::make($request->password), // Enkripsi password
            'nik' => $request->nik,
            'alamat' => $request->alamat,
            'jenis_kelamin' => $request->jenis_kelamin,
            'tanggal_lahir' => $request->tanggal_lahir,
            'jabatan' => $request->jabatan,
        ]);

        return redirect()->route('accounts.index')->with('success', 'Akun berhasil ditambahkan.');
    }

    public function update(Request $request, User $user)
    {
        if (auth()->user()->jabatan !== 'Administrator') {
            abort(403, 'Akses ditolak.');
        }

        // 1. Definisikan Validasi
        $validatedData = $request->validate([
            'nama_lengkap' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users,email,' . $user->id,
            'password' => 'sometimes|nullable|string|min:8', // Password dibuat opsional
            'nik' => 'nullable|string|max:255',
            'alamat' => 'nullable|string',
            'jenis_kelamin' => 'nullable|string|max:255',
            'tanggal_lahir' => 'nullable|date',
            'jabatan' => 'required|in:Administrator,Sales,Teknisi',
        ]);

        // 2. Siapkan Data Update
        $dataToUpdate = $validatedData;

        // 3. Logika Update Password
        if (!empty($request->input('password'))) {
            // Jika password diisi, enkripsi dan tambahkan ke data update
            $dataToUpdate['password'] = Hash::make($request->input('password'));
        } else {
            // Hapus field password dari data update agar tidak meng-overwrite dengan NULL
            unset($dataToUpdate['password']);
        }

        // 4. Lakukan Update
        $user->update($dataToUpdate);

        return redirect()->route('accounts.index')->with('success', 'Akun berhasil diperbarui.');
    }

    public function reset2FA(Request $request, User $user)
    {
        if (auth()->user()->jabatan !== 'Administrator') {
            abort(403, 'Akses ditolak.');
        }

        $user->google2fa_secret = null;
        $user->save();

        return response()->json(['message' => '2FA berhasil direset.']);
    }

    public function show2FA(User $user)
    {
        if (auth()->user()->jabatan !== 'Administrator') {
            abort(403, 'Akses ditolak.');
        }

        if (!$user->google2fa_secret) {
            return response()->json(['error' => 'User belum mengaktifkan 2FA'], 404);
        }

        $google2fa = new Google2FA();

        $qrText = $google2fa->getQRCodeUrl(
            config('app.name'),
            $user->email,
            $user->google2fa_secret
        );

        $renderer = new ImageRenderer(
            new RendererStyle(200),
            new SvgImageBackEnd()
        );
        $writer = new Writer($renderer);
        $qrCodeSvg = $writer->writeString($qrText);

        return response()->json([
            'secret' => $user->google2fa_secret,
            'qr' => $qrCodeSvg, // <== Jangan pakai addslashes
        ]);
    }


    public function destroy(User $user)
    {
        if (auth()->user()->jabatan !== 'Administrator') {
            abort(403, 'Akses ditolak.');
        }

        $user->delete();

        // Ubah ini untuk mengirim pesan sukses
        return redirect()->route('accounts.index')->with('success', 'Akun berhasil dihapus.');
    }
}
