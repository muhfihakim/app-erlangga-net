<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{
    protected $fillable = [
        'pre_order_id',
        'id_sales',
        'id_teknisi',
        'nama_lengkap',
        'alamat_lengkap',
        'no_whatsapp',
        'paket_internet',
        'id_pelanggan',
        'pppoe_username',
        'pppoe_password',
        'jenis_modem',
        'sn_perangkat',
        'pembayaran',
        'partner',
        'keterangan',
        'foto_petugas',
        'foto_terpasang',
        'foto_speedtest',
    ];

    // Relasi ke PreOrder
    public function preOrder()
    {
        return $this->belongsTo(PreOrder::class);
    }
}
