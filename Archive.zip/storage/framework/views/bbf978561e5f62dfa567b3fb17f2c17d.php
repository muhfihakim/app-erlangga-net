<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('Css'); ?>
        <!-- DataTables -->
        <link rel="stylesheet" href="<?php echo e(asset('dist/css/dataTables.bootstrap4.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('dist/css/responsive.bootstrap4.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('dist/css/buttons.bootstrap4.min.css')); ?>">
    <?php $__env->stopSection(); ?>
    <main class="app-main">
        <!--begin::App Content Header-->
        <div class="app-content-header">
            <!--begin::Container-->
            <div class="container-fluid">
                <!--begin::Row-->
                <div class="row">
                    <div class="col-sm-6">
                        <h3 class="mb-0">Manajemen</h3>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-end">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Akun</li>
                        </ol>
                    </div>
                </div>
                <!--end::Row-->
            </div>
            <!--end::Container-->
        </div>
        <div class="app-content">
            <div class="card card-primary">
                <div class="card-header">
                    <h3 class="card-title">Akun</h3>
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                    
                    <button type="button" class="btn btn-success mb-3 btn-sm" data-bs-toggle="modal"
                        data-bs-target="#addUserModal">
                        <i class="bi bi-plus-square"></i> Tambah Akun
                    </button>
                    <a href="<?php echo e(route('dashboards.index')); ?>" class="btn btn-secondary mb-3 btn-sm">← Kembali</a>
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th style="text-align: center">No</th>
                                <th style="text-align: center">Nama Lengkap</th>
                                <th style="text-align: center">NIK</th>
                                <th style="text-align: center">Alamat</th>
                                <th style="text-align: center">Jenis Kelamin</th>
                                <th style="text-align: center">Tanggal Lahir</th>
                                <th style="text-align: center">Email</th>
                                <th style="text-align: center">Jabatan</th>
                                <th style="text-align: center">Opsi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td style="text-align: center; vertical-align: middle"><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($user->nama_lengkap); ?></td>
                                    <td style="text-align: center; vertical-align: middle"><?php echo e($user->nik); ?></td>
                                    <td><?php echo e($user->alamat); ?></td>
                                    <td style="text-align: center; vertical-align: middle"><?php echo e($user->jenis_kelamin); ?>

                                    </td>
                                    <td style="text-align: center; vertical-align: middle">
                                        <?php echo e(\Carbon\Carbon::parse($user->tanggal_lahir)->format('d-m-Y')); ?>

                                    </td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td style="text-align: center; vertical-align: middle"><?php echo e($user->jabatan); ?></td>
                                    <td style="text-align: center; vertical-align: middle">
                                        <button type="button" class="btn btn-warning btn-sm" data-bs-toggle="modal"
                                            data-bs-target="#editModal" data-user-id="<?php echo e($user->id); ?>"
                                            data-user-nama="<?php echo e($user->nama_lengkap); ?>"
                                            data-user-nik="<?php echo e($user->nik); ?>" data-user-alamat="<?php echo e($user->alamat); ?>"
                                            data-user-jk="<?php echo e($user->jenis_kelamin); ?>"
                                            data-user-tgl="<?php echo e(\Carbon\Carbon::parse($user->tanggal_lahir)->format('Y-m-d')); ?>"
                                            data-user-email="<?php echo e($user->email); ?>"
                                            data-user-jabatan="<?php echo e($user->jabatan); ?>">
                                            <i class="bi bi-pencil-square"></i>
                                        </button>

                                        <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal"
                                            data-bs-target="#deleteModal" data-user-id="<?php echo e($user->id); ?>">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="modal fade" id="addUserModal" tabindex="-1" aria-labelledby="addUserModalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="addUserModalLabel">Tambah Akun Baru</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <form id="addForm" method="POST" action="<?php echo e(route('accounts.store')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="modal-body">
                                    <div class="mb-3">
                                        <label for="add_nama_lengkap" class="form-label">Nama Lengkap</label>
                                        <input type="text" class="form-control" id="add_nama_lengkap"
                                            name="nama_lengkap" placeholder="Masukkan Nama Lengkap" required
                                            autocomplete="off">
                                    </div>
                                    <div class="mb-3">
                                        <label for="add_email" class="form-label">Alamat Email</label>
                                        <input type="email" class="form-control" id="add_email" name="email"
                                            placeholder="Masukkan Alamat Email" required autocomplete="off">
                                    </div>
                                    <div class="mb-3">
                                        <label for="add_password" class="form-label">Password</label>
                                        <input type="password" class="form-control" id="add_password"
                                            name="password" placeholder="Masukkan Password" required
                                            autocomplete="off">
                                    </div>
                                    <div class="mb-3">
                                        <label for="add_nik" class="form-label">NIK</label>
                                        <input type="text" class="form-control" id="add_nik" name="nik"
                                            placeholder="Masukkan NIK" autocomplete="off">
                                    </div>
                                    <div class="mb-3">
                                        <label for="add_alamat" class="form-label">Alamat Lengkap</label>
                                        <textarea class="form-control" id="add_alamat" name="alamat" placeholder="Masukkan Alamat Lengkap"
                                            autocomplete="off"></textarea>
                                    </div>
                                    <div class="mb-3">
                                        <label for="add_jenis_kelamin" class="form-label">Jenis Kelamin</label>
                                        <select class="form-control" id="add_jenis_kelamin" name="jenis_kelamin">
                                            <option value="">Pilih Jenis Kelamin</option>
                                            <option value="Laki-laki">Laki-laki</option>
                                            <option value="Perempuan">Perempuan</option>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label for="add_tanggal_lahir" class="form-label">Tanggal Lahir</label>
                                        <input type="date" class="form-control" id="add_tanggal_lahir"
                                            name="tanggal_lahir" autocomplete="off">
                                    </div>
                                    <div class="mb-3">
                                        <label for="add_jabatan" class="form-label">Jabatan</label>
                                        <select class="form-control" id="add_jabatan" name="jabatan">
                                            <option value="">Pilih Jabatan</option>
                                            <option value="Administrator">Administrator</option>
                                            <option value="Sales">Sales</option>
                                            <option value="Teknisi">Teknisi</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary btn-sm"
                                        data-bs-dismiss="modal">Tutup</button>
                                    <button type="submit" class="btn btn-primary btn-sm">Simpan</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="editModalLabel">Edit Akun Pengguna</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <form id="editForm" method="POST" action="">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="modal-body">
                                    <div class="mb-3">
                                        <label for="nama_lengkap" class="form-label">Nama Lengkap</label>
                                        <input type="text" class="form-control" id="nama_lengkap"
                                            name="nama_lengkap" placeholder="Masukkan Nama Lengkap" required
                                            autocomplete="off">
                                    </div>
                                    <div class="mb-3">
                                        <label for="email" class="form-label">Alamat Email</label>
                                        <input type="email" class="form-control" id="email" name="email"
                                            placeholder="Masukkan Alamat Email" required autocomplete="off">
                                    </div>
                                    <div class="mb-3">
                                        <label for="password" class="form-label">Password Baru (Opsional)</label>
                                        <input type="password" class="form-control" id="password" name="password"
                                            placeholder="Kosongkan jika tidak ingin mengganti password"
                                            autocomplete="off">
                                    </div>
                                    <div class="mb-3">
                                        <label for="nik" class="form-label">NIK</label>
                                        <input type="text" class="form-control" id="nik" name="nik"
                                            placeholder="Masukkan NIK" autocomplete="off">
                                    </div>
                                    <div class="mb-3">
                                        <label for="alamat" class="form-label">Alamat</label>
                                        <textarea class="form-control" id="alamat" name="alamat" placeholder="Masukkan Alamat Lengkap"
                                            autocomplete="off"></textarea>
                                    </div>
                                    <div class="mb-3">
                                        <label for="jenis_kelamin" class="form-label">Jenis Kelamin</label>
                                        <select class="form-control" id="jenis_kelamin" name="jenis_kelamin">
                                            <option value="">Pilih Jenis Kelamin</option>
                                            <option value="Laki-laki">Laki-laki</option>
                                            <option value="Perempuan">Perempuan</option>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label for="tanggal_lahir" class="form-label">Tanggal Lahir</label>
                                        <input type="date" class="form-control" id="tanggal_lahir"
                                            name="tanggal_lahir" autocomplete="off">
                                    </div>
                                    <div class="mb-3">
                                        <label for="jabatan" class="form-label">Jabatan</label>
                                        <select class="form-control" id="jabatan" name="jabatan">
                                            <option value="Administrator">Administrator</option>
                                            <option value="Sales">Sales</option>
                                            <option value="Teknisi">Teknisi</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary btn-sm"
                                        data-bs-dismiss="modal">Tutup</button>
                                    <button type="submit" class="btn btn-primary btn-sm">Simpan</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="deleteModalLabel">Konfirmasi Hapus</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                Apakah Anda yakin ingin menghapus akun ini?
                            </div>
                            <div class="modal-footer">
                                <form id="deleteForm" method="POST" action="">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="button" class="btn btn-secondary btn-sm"
                                        data-bs-dismiss="modal">Batal</button>
                                    <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end::App Content-->
            </div>
        </div>
    </main>
    <!--end::App Main-->
    <?php $__env->startSection('Scripts'); ?>
        <!-- jQuery -->
        <script src="<?php echo e(asset('dist/js/jquery.min.js')); ?>"></script>
        <!-- Bootstrap 4 -->
        <script src="<?php echo e(asset('dist/js/bootstrap.bundle.min.js')); ?>"></script>
        <!-- DataTables  & js -->
        <script src="<?php echo e(asset('dist/js/jquery.dataTables.min.js')); ?>"></script>
        <script src="<?php echo e(asset('dist/js/dataTables.bootstrap4.min.js')); ?>"></script>
        <script src="<?php echo e(asset('dist/js/dataTables.responsive.min.js')); ?>"></script>
        <script src="<?php echo e(asset('dist/js/responsive.bootstrap4.min.js')); ?>"></script>
        <script src="<?php echo e(asset('dist/js/dataTables.buttons.min.js')); ?>"></script>
        <script src="<?php echo e(asset('dist/js/buttons.bootstrap4.min.js')); ?>"></script>
        <script src="<?php echo e(asset('dist/js/buttons.colVis.min.js')); ?>"></script>
        <!-- AdminLTE App -->
        <script>
            function submitStatus(id, statusValue) {
                document.getElementById('statusInput' + id).value = statusValue;
                document.getElementById('statusForm' + id).submit();
            }
        </script>
        <!-- Page specific script -->
        <script>
            $(function() {
                $("#example1").DataTable({
                    "responsive": true,
                    "lengthChange": false,
                    "autoWidth": false,
                    "ordering": false,
                }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
            });
        </script>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <script>
            // Logika untuk menampilkan SweetAlert
            <?php if(session('success')): ?>
                Swal.fire({
                    icon: 'success',
                    title: 'Berhasil!',
                    text: '<?php echo e(session('success')); ?>',
                    showConfirmButton: false,
                    timer: 3000
                });
            <?php endif; ?>

            <?php if(session('error')): ?>
                Swal.fire({
                    icon: 'error',
                    title: 'Oops...',
                    text: '<?php echo e(session('error')); ?>',
                });
            <?php endif; ?>
        </script>
        <script>
            // Logika untuk Modal Edit
            const editModal = document.getElementById('editModal');
            editModal.addEventListener('show.bs.modal', event => {
                const button = event.relatedTarget;
                const userId = button.getAttribute('data-user-id');
                const userNama = button.getAttribute('data-user-nama');
                const userNik = button.getAttribute('data-user-nik');
                const userAlamat = button.getAttribute('data-user-alamat');
                const userJenisKelamin = button.getAttribute('data-user-jk');
                const userTanggalLahir = button.getAttribute('data-user-tgl');
                const userEmail = button.getAttribute('data-user-email');
                const userJabatan = button.getAttribute('data-user-jabatan');

                const modalTitle = editModal.querySelector('.modal-title');
                const modalForm = editModal.querySelector('#editForm');
                const modalBodyInputNama = editModal.querySelector('#nama_lengkap');
                const modalBodyInputNik = editModal.querySelector('#nik');
                const modalBodyInputAlamat = editModal.querySelector('#alamat');
                const modalBodyInputJenisKelamin = editModal.querySelector('#jenis_kelamin');
                const modalBodyInputTanggalLahir = editModal.querySelector('#tanggal_lahir');
                const modalBodyInputEmail = editModal.querySelector('#email');
                const modalBodyInputJabatan = editModal.querySelector('#jabatan');

                modalTitle.textContent = `Edit Akun: ${userNama}`;
                modalForm.action = `/accounts/${userId}`; // Ubah URL action form
                modalBodyInputNama.value = userNama;
                modalBodyInputNik.value = userNik;
                modalBodyInputAlamat.value = userAlamat;
                modalBodyInputJenisKelamin.value = userJenisKelamin;
                modalBodyInputTanggalLahir.value = userTanggalLahir;
                modalBodyInputEmail.value = userEmail;
                modalBodyInputJabatan.value = userJabatan;
            });

            // Logika untuk Modal Hapus
            const deleteModal = document.getElementById('deleteModal');
            deleteModal.addEventListener('show.bs.modal', event => {
                const button = event.relatedTarget;
                const userId = button.getAttribute('data-user-id');
                const modalForm = deleteModal.querySelector('#deleteForm');

                modalForm.action = `/accounts/${userId}`;
            });
        </script>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH /Users/bbs/Documents/Project/erlangga-net/resources/views/account-manage.blade.php ENDPATH**/ ?>