 <!--begin::Sidebar-->
 <aside class="app-sidebar bg-body-secondary shadow" data-bs-theme="dark">
     <!--begin::Sidebar Brand-->
     <div class="sidebar-brand">
         <!--begin::Brand Link-->
         <a href="/" class="brand-link">
             <!--begin::Brand Image-->
             <img src="<?php echo e(asset('dist/assets/img/logo.png')); ?>" alt="Logo Pemprov Papua Tengah" class="brand-image" />
             <!--end::Brand Image-->
         </a>
         <!--end::Brand Link-->
     </div>
     <!--end::Sidebar Brand-->
     <!--begin::Sidebar Wrapper-->
     <div class="sidebar-wrapper">
         <nav class="mt-2">
             <!--begin::Sidebar Menu-->
             <ul class="nav sidebar-menu flex-column" data-lte-toggle="treeview" role="menu" data-accordion="false">
                 
                 <li class="nav-item">
                     <a href="<?php echo e(route('dashboards.index')); ?>"
                         class="nav-link <?php echo e(Request::is('dashboard') ? 'active' : ''); ?>">
                         <i class="bi bi-exclamation-square"></i>
                         <p>Dashboard</p>
                     </a>
                 </li>
                 <li class="nav-header">PELANGGAN</li>
                 <?php if(auth()->check() && auth()->user()->jabatan === 'Teknisi'): ?>
                     <li class="nav-item">
                         <a href="<?php echo e(route('customers.index')); ?>"
                             class="nav-link <?php echo e(Request::is('customers') ? 'active' : ''); ?>">
                             <i class="bi bi-person-check"></i>
                             <p>Aktivasi</p>
                         </a>
                     </li>
                 <?php endif; ?>
                 
                 
                 <?php if(auth()->check() && (auth()->user()->jabatan === 'Administrator' || auth()->user()->jabatan === 'Sales')): ?>
                     <li class="nav-item">
                         <a href="<?php echo e(route('customers.active_list')); ?>"
                             class="nav-link <?php echo e(Request::is('customers/active-list') ? 'active' : ''); ?>">
                             <i class="bi bi-people-fill"></i>
                             <p>Aktivasi</p>
                         </a>
                     </li>
                 <?php endif; ?>
                 <?php if(auth()->check() && in_array(auth()->user()->jabatan, ['Administrator', 'Sales'])): ?>
                     <li class="nav-item">
                         <a href="<?php echo e(route('pre_orders.index')); ?>"
                             class="nav-link <?php echo e(Request::is('pre-orders') ? 'active' : ''); ?>">
                             <i class="bi bi-file-earmark-text"></i>
                             <p>Pre-Order</p>
                         </a>
                     </li>
                 <?php endif; ?>
                 <?php if(auth()->check() && auth()->user()->jabatan === 'Administrator'): ?>
                     <li class="nav-header">MANAJEMEN</li>
                     <li class="nav-item">
                         <a href="<?php echo e(route('accounts.tracking')); ?>"
                             class="nav-link <?php echo e(Request::is('tracking') ? 'active' : ''); ?>">
                             <i class="bi bi-geo-alt"></i>
                             <p>Lacak Akun</p>
                         </a>
                     </li>
                 <?php endif; ?>
                 <?php if(auth()->check() && auth()->user()->jabatan === 'Administrator'): ?>
                     <li class="nav-item">
                         <a href="<?php echo e(route('accounts.index')); ?>"
                             class="nav-link <?php echo e(Request::is('accounts') ? 'active' : ''); ?>">
                             <i class="bi bi-person-gear"></i>
                             <p>Akun</p>
                         </a>
                     </li>
                 <?php endif; ?>
             </ul>
             <!--end::Sidebar Menu-->
         </nav>
     </div>
     <!--end::Sidebar Wrapper-->
 </aside>
 <!--end::Sidebar-->
<?php /**PATH /Users/bbs/Documents/Project/erlangga-net/resources/views/components/layouts/sidebar.blade.php ENDPATH**/ ?>