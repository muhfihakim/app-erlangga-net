<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('Css'); ?>
        <!-- Ionicons -->
        <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <?php $__env->stopSection(); ?>
    <main class="app-main">
        <div class="app-content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-6">
                        <h3 class="mb-0">Dashboard</h3>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-end">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="app-content">
            <!-- Main content -->
            <section class="content">
                <div class="container-fluid">
                    <!-- Small boxes (Stat box) -->
                    <div class="row">
                        <?php if($user->jabatan !== 'Teknisi'): ?>

                            <div class="col-lg-3 col-6">
                                <!-- small box -->
                                <div class="small-box bg-info">
                                    <div class="inner">
                                        <!-- Menampilkan Total PO Bulan Ini -->
                                        <h3><?php echo e($totalPoThisMonth); ?></h3>

                                        <p>Total PO Bulan Ini</p>
                                    </div>
                                    <a href="#" class="small-box-footer">Lihat Detail <i
                                            class="fas fa-arrow-circle-right"></i></a>
                                </div>
                            </div>
                            <!-- ./col -->
                            <div class="col-lg-3 col-6">
                                <!-- small box -->
                                <div class="small-box bg-warning">
                                    <div class="inner">
                                        <!-- Menampilkan Total PO Bulan Sebelumnya dan Persentase Perubahan -->
                                        <h3><?php echo e($totalPoPreviousMonth); ?>

                                            <!-- Menampilkan persentase perubahan di sini -->
                                            <sup style="font-size: 20px;">
                                                <?php if($percentageChange > 0): ?>
                                                    +<?php echo e(round($percentageChange, 1)); ?>% <i class="fas fa-arrow-up"></i>
                                                <?php elseif($percentageChange < 0): ?>
                                                    <?php echo e(round($percentageChange, 1)); ?>% <i class="fas fa-arrow-down"></i>
                                                <?php else: ?>
                                                    0%
                                                <?php endif; ?>
                                            </sup>
                                        </h3>

                                        <p>Total PO Bulan Sebelumnya</p>
                                    </div>
                                    <a href="#" class="small-box-footer">Lihat Detail <i
                                            class="fas fa-arrow-circle-right"></i></a>
                                </div>
                            </div>
                            <!-- ./col -->
                            <div class="col-lg-3 col-6">
                                <div class="small-box bg-success">
                                    <div class="inner">
                                        <h3><?php echo e($totalAktivasiThisMonth); ?></h3>

                                        <p>Total Aktivasi Bulan Ini</p>
                                    </div>
                                    <a href="#" class="small-box-footer">Lihat Detail <i
                                            class="fas fa-arrow-circle-right"></i></a>
                                </div>
                            </div>
                            <div class="col-lg-3 col-6">
                                <div class="small-box bg-danger">
                                    <div class="inner">
                                        <h3><?php echo e($totalPendingThisMonth); ?></h3>

                                        <p>Total Pending Bulan Ini</p>
                                    </div>
                                    <a href="#" class="small-box-footer">Lihat Detail <i
                                            class="fas fa-arrow-circle-right"></i></a>
                                </div>
                            </div>
                        <?php endif; ?>
                        
                    </div>
                    <div>
                        <?php if(Auth::user()->jabatan === 'Teknisi'): ?>
                            <div class="row mt-4">
                                <div class="col-12">
                                    <h4><i class="fas fa-tasks text-primary"></i> Tugas Delegasi Khusus Anda</h4>
                                    <p class="text-muted">Daftar Pre-Order yang ditugaskan kepada Anda dan belum
                                        diaktivasi.</p>
                                </div>
                            </div>

                            <div class="row">
                                <?php $__empty_1 = true; $__currentLoopData = $delegatedTasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="col-md-6 col-lg-4 mb-4">
                                        <div class="card <?php echo e($task->bg_color ?? 'bg-light'); ?>">
                                            <div class="card-header border-0">
                                                <h5 class="card-title text-uppercase fw-bold">
                                                    <?php echo e(Str::limit($task->nama_lengkap, 25)); ?></h5>
                                                <div class="card-tools">
                                                    <span
                                                        class="badge <?php echo e($task->bg_color ?? 'bg-secondary'); ?>"><?php echo e($task->status_display); ?></span>
                                                </div>
                                            </div>
                                            <div class="card-body">
                                                <p class="card-text mb-1">
                                                    <i class="bi bi-wifi"></i> Paket: <?php echo e($task->paket_internet); ?>

                                                </p>
                                                <p class="card-text mb-1">
                                                    <i class="bi bi-geo-alt"></i> Alamat:
                                                    <?php echo e(Str::limit($task->alamat_lengkap, 35)); ?>

                                                </p>
                                                <p class="card-text mb-1">
                                                    <i class="bi bi-whatsapp"></i> WhatsApp:
                                                    <?php echo e($task->no_whatsapp); ?>

                                                </p>
                                                <hr class="my-2">
                                                <div class="row small">
                                                    <div class="col-4 text-center">
                                                        <strong>Tgl PO</strong><br>
                                                        <span
                                                            class="fw-bold"><?php echo e(\Carbon\Carbon::parse($task->created_at)->format('d-m-Y')); ?></span>
                                                    </div>
                                                    <div class="col-4 text-center">
                                                        <strong>Tgl Delegasi</strong><br>
                                                        <span
                                                            class="fw-bold"><?php echo e(\Carbon\Carbon::parse($task->delegated_at)->format('d-m-Y')); ?></span>
                                                    </div>
                                                    <div class="col-4 text-center">
                                                        <strong>Deadline</strong><br>
                                                        <span
                                                            class="fw-bold"><?php echo e($task->deadline_date ?? 'N/A'); ?></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="card-footer text-center">
                                                <a href="<?php echo e(route('customers.index')); ?>" class="btn btn-sm">
                                                    Lihat Detail Tugas
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <div class="col-12">
                                        <div class="alert alert-success text-center">
                                            <i class="fas fa-check-circle"></i> Tidak ada tugas delegasi khusus saat
                                            ini.
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div><!-- /.container-fluid -->
            </section>
            <!-- /.content -->
        </div>
    </main>
    <?php $__env->startSection('Scripts'); ?>
        <!-- jQuery -->
        <script src="https://adminlte.io/themes/v3/plugins/jquery/jquery.min.js"></script>
        <!-- jQuery UI 1.11.4 -->
        <script src="https://adminlte.io/themes/v3/plugins/jquery-ui/jquery-ui.min.js"></script>
        <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
        <script>
            $.widget.bridge('uibutton', $.ui.button)
        </script>
        <!-- Bootstrap 4 -->
        <script src="https://adminlte.io/themes/v3/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
        <!-- ChartJS -->
        <script src="https://adminlte.io/themes/v3/plugins/chart.js/Chart.min.js"></script>
        <!-- Sparkline -->
        <script src="https://adminlte.io/themes/v3/plugins/sparklines/sparkline.js"></script>
        <!-- JQVMap -->
        <script src="https://adminlte.io/themes/v3/plugins/jqvmap/jquery.vmap.min.js"></script>
        <script src="https://adminlte.io/themes/v3/plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
        <!-- jQuery Knob Chart -->
        <script src="https://adminlte.io/themes/v3/plugins/jquery-knob/jquery.knob.min.js"></script>
        <!-- daterangepicker -->
        <script src="https://adminlte.io/themes/v3/plugins/moment/moment.min.js"></script>
        <script src="https://adminlte.io/themes/v3/plugins/daterangepicker/daterangepicker.js"></script>
        <!-- Tempusdominus Bootstrap 4 -->
        <script src="https://adminlte.io/themes/v3/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js">
        </script>
        <!-- Summernote -->
        <script src="https://adminlte.io/themes/v3/plugins/summernote/summernote-bs4.min.js"></script>
        <!-- overlayScrollbars -->
        <script src="https://adminlte.io/themes/v3/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
        <!-- AdminLTE App -->
        <script src="https://adminlte.io/themes/v3/dist/js/adminlte.js?v=3.2.0"></script>
        <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
        <script src="https://adminlte.io/themes/v3/dist/js/pages/dashboard.js"></script>
        <script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015"
            integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ=="
            data-cf-beacon='{"version":"2024.11.0","token":"2437d112162f4ec4b63c3ca0eb38fb20","server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}'
            crossorigin="anonymous"></script>
        <script>
            function updateClock() {
                // Objek Date JavaScript mengambil waktu lokal browser
                const now = new Date();

                // Atur format waktu (misalnya: 15:30:45 WIB)
                const timeOptions = {
                    hour: '2-digit',
                    minute: '2-digit',
                    second: '2-digit',
                    hour12: false
                };

                // Mendapatkan waktu dalam format lokal Indonesia (ID)
                const timeString = now.toLocaleTimeString('id-ID', timeOptions);

                // Menampilkan waktu
                document.getElementById('realtime-clock').innerHTML = timeString;
            }

            // Panggil fungsi sekali saat halaman dimuat
            updateClock();

            // Panggil fungsi setiap 1 detik (1000 milidetik)
            setInterval(updateClock, 1000);
        </script>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH /Users/bbs/Documents/Project/erlangga-net/resources/views/dashboard.blade.php ENDPATH**/ ?>