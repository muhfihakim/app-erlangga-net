<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('Css'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('dist/css/dataTables.bootstrap4.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('dist/css/responsive.bootstrap4.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('dist/css/buttons.bootstrap4.min.css')); ?>">
        <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <?php $__env->stopSection(); ?>
    <main class="app-main">
        <div class="app-content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-6">
                        <h3 class="mb-0">Pelanggan</h3>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-end">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Pre-Order</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="app-content">
            <div class="card card-primary">
                <div class="card-header">
                    <h3 class="card-title">Data Keseluruhan Pre-Order</h3>
                </div>
                <div class="card-body">
                    
                    <?php if(auth()->user()->jabatan === 'Sales' || auth()->user()->jabatan === 'Administrator'): ?>
                        <button type="button" class="btn btn-success mb-3 btn-sm" data-bs-toggle="modal"
                            data-bs-target="#addPreOrderModal">
                            <i class="bi bi-plus-square"></i> Tambah Pre-Order
                        </button>
                        <a href="<?php echo e(route('dashboards.index')); ?>" class="btn btn-secondary mb-3 btn-sm">← Kembali</a>
                    <?php endif; ?>

                    <table id="example1" class="table table-bordered">
                        <thead>
                            <tr>
                                <th style="text-align: center">No</th>
                                <th style="text-align: center">Tgl PO</th>
                                <th style="text-align: center">Sales</th>
                                <th style="text-align: center">Nama</th>
                                <th style="text-align: center">Paket</th>
                                <th style="text-align: center">Alamat</th>
                                <th style="text-align: center">Foto</th>
                                <th style="text-align: center">No. WA</th>
                                <th style="text-align: center">Opsi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $preOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $po): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td style="text-align: center; vertical-align: middle;"><?php echo e($loop->iteration); ?></td>
                                    <td style="text-align: center; vertical-align: middle;">
                                        <?php echo e(\Carbon\Carbon::parse($po->created_at)->format('d-m-Y')); ?></td>
                                    <td style="text-align: center; vertical-align: middle;"><?php echo e($po->nama_sales); ?></td>
                                    <td style="vertical-align: middle"><?php echo e($po->nama_lengkap); ?></td>
                                    <td style="vertical-align: middle"><?php echo e($po->paket_internet); ?>

                                    </td>
                                    <td style="text-align: center; vertical-align: middle;">
                                        <a href="#" data-bs-toggle="modal" data-bs-target="#alamatModal"
                                            data-alamat-lengkap="<?php echo e($po->alamat_lengkap); ?>">
                                            <?php echo e(Str::limit($po->alamat_lengkap, 15, '...')); ?>

                                        </a>
                                    </td>
                                    <td style="text-align: center; vertical-align: middle;">
                                        <?php if($po->foto_ktp): ?>
                                            <button type="button" class="btn btn-info btn-sm" data-bs-toggle="modal"
                                                data-bs-target="#viewKtpModal"
                                                data-ktp-url="<?php echo e(asset('storage/' . $po->foto_ktp)); ?>">
                                                <i class="bi bi-eye"></i> KTP
                                            </button>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>

                                        <?php if($po->foto_rumah): ?>
                                            <button type="button" class="btn btn-info btn-sm" data-bs-toggle="modal"
                                                data-bs-target="#viewRumahModal"
                                                data-rumah-url="<?php echo e(asset('storage/' . $po->foto_rumah)); ?>">
                                                <i class="bi bi-eye"></i> Rumah
                                            </button>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                    <td style="text-align: center; vertical-align: middle;">
                                        <a href="https://wa.me/<?php echo e($po->no_whatsapp); ?>" target="_blank"
                                            class="btn btn-success btn-sm">
                                            <i class="bi bi-whatsapp"></i> <?php echo e($po->no_whatsapp); ?>

                                        </a>
                                    </td>
                                    <td style="text-align: center; vertical-align: middle;">
                                        <button type="button" class="btn btn-secondary btn-sm" data-bs-toggle="modal"
                                            data-bs-target="#detailModal" data-identitas="<?php echo e($po->no_identitas); ?>"
                                            data-email-lengkap="<?php echo e($po->alamat_email); ?>">
                                            <i class="bi bi-person-lines-fill"></i>
                                        </button>
                                        <?php if($po->titik_koordinat): ?>
                                            <button type="button" class="btn btn-primary btn-sm show-map-btn"
                                                data-bs-toggle="modal" data-bs-target="#mapModal"
                                                data-koordinat="<?php echo e($po->titik_koordinat); ?>">
                                                <i class="bi bi-geo-alt-fill"></i>
                                            </button>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                        <?php if(Auth::user()->jabatan === 'Administrator'): ?>
                                            
                                            <?php
                                                $isDelegated = $po->id_teknisi_delegasi !== null;
                                                $isExpired = $po->is_expired ?? false; // Dari Controller
                                                $isSegeraExpired = $po->is_segera_expired ?? false; // Dari Controller
                                                $isActive = $po->is_active ?? false; // Dari Controller
                                                $teknisi = $isDelegated
                                                    ? App\Models\User::find($po->id_teknisi_delegasi)
                                                    : null;
                                                $teknisiNama = $teknisi->nama_lengkap ?? 'N/A';
                                                $delegatedAt = $po->delegated_at
                                                    ? \Carbon\Carbon::parse($po->delegated_at)->format('d/m')
                                                    : '';
                                                $delegatedFullDate = $po->delegated_at
                                                    ? \Carbon\Carbon::parse($po->delegated_at)->format('d-m-Y')
                                                    : 'N/A';
                                            ?>

                                            <?php if($isActive): ?>
                                                
                                                <button type="button" class="btn btn-success btn-sm" disabled
                                                    title="Pelanggan Sudah Aktif">
                                                    <i class="bi bi-person-check"></i> AKTIF
                                                </button>
                                                <p class="text-success small mt-1 mb-0" style="font-size: 0.75rem;">
                                                    Lihat di Pelanggan Aktif
                                                </p>
                                            <?php elseif($isDelegated): ?>
                                                

                                                <?php
                                                    $buttonClass = 'btn-secondary';
                                                    if ($isExpired) {
                                                        $buttonClass = 'btn-danger';
                                                    } elseif ($isSegeraExpired) {
                                                        $buttonClass = 'btn-warning text-dark';
                                                    }
                                                ?>

                                                <button type="button" class="btn <?php echo e($buttonClass); ?> btn-sm" disabled
                                                    data-bs-toggle="tooltip" data-bs-placement="top"
                                                    title="Ditugaskan ke <?php echo e($teknisiNama); ?> pada <?php echo e($delegatedFullDate); ?>">

                                                    <?php if($isExpired): ?>
                                                        <i class="bi bi-clock-history"></i> EXPIRED
                                                    <?php elseif($isSegeraExpired): ?>
                                                        <i class="bi bi-hourglass-split"></i> SEGERA!
                                                    <?php else: ?>
                                                        <i class="bi bi-check-circle-fill"></i> Ditugaskan
                                                    <?php endif; ?>
                                                </button>

                                                <small
                                                    class="d-block mt-1 <?php echo e($isExpired ? 'text-danger' : 'text-muted'); ?>"
                                                    style="font-size: 0.85rem;">
                                                    <?php echo e(Str::limit($teknisiNama, 10, '...')); ?> (<?php echo e($delegatedAt); ?>)
                                                </small>

                                                
                                                <button type="button"
                                                    class="btn btn-danger btn-sm reset-btn mt-1 btn-sm"
                                                    data-bs-toggle="modal" data-bs-target="#resetModal"
                                                    data-po-id="<?php echo e($po->id); ?>"
                                                    data-po-nama="<?php echo e($po->nama_lengkap); ?>">
                                                    <i class="bi bi-x-circle"></i> Reset
                                                </button>
                                            <?php else: ?>
                                                
                                                <button type="button" class="btn btn-info btn-sm delegate-btn"
                                                    data-bs-toggle="modal" data-bs-target="#delegateModal"
                                                    data-po-id="<?php echo e($po->id); ?>"
                                                    data-po-nama="<?php echo e($po->nama_lengkap); ?>">
                                                    <i class="bi bi-person-badge"></i> Tugas
                                                </button>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        <button type="button" class="btn btn-warning btn-sm" data-bs-toggle="modal"
                                            data-bs-target="#editModal" data-po-id="<?php echo e($po->id); ?>"
                                            data-po-nama="<?php echo e($po->nama_lengkap); ?>"
                                            data-po-paket="<?php echo e($po->paket_internet); ?>"
                                            data-po-wa="<?php echo e($po->no_whatsapp); ?>"
                                            data-po-email="<?php echo e($po->alamat_email); ?>"
                                            data-po-alamat="<?php echo e($po->alamat_lengkap); ?>"
                                            data-po-identitas="<?php echo e($po->no_identitas); ?>"
                                            data-po-koordinat="<?php echo e($po->titik_koordinat); ?>"
                                            data-po-foto-ktp="<?php echo e($po->foto_ktp); ?>"
                                            data-po-foto-rumah="<?php echo e($po->foto_rumah); ?>">
                                            <i class="bi bi-pencil-square"></i>
                                        </button>

                                        <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal"
                                            data-bs-target="#deleteModal" data-po-id="<?php echo e($po->id); ?>">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
    <?php echo $__env->make('partials.modal_preorders', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('partials.script_preorders', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH /Users/bbs/Documents/Project/erlangga-net v0.1/resources/views/preorders.blade.php ENDPATH**/ ?>