<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('Css'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('dist/css/dataTables.bootstrap4.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('dist/css/dataTables.bootstrap4.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('dist/css/responsive.bootstrap4.min.css')); ?>">
    <?php $__env->stopSection(); ?>
    <main class="app-main">
        <div class="app-content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-6">
                        <h3 class="mb-0">Pelanggan</h3>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-end">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Aktivasi</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="app-content">
            <div class="card card-primary">
                <div class="card-header">
                    <h3 class="card-title">
                        <?php if(auth()->user()->jabatan === 'Administrator'): ?>
                            Data Keseluruhan Pelanggan
                        <?php else: ?>
                            Pelanggan Anda
                        <?php endif; ?>
                    </h3>
                </div>
                <div class="card-body">
                    <a href="<?php echo e(route('dashboards.index')); ?>" class="btn btn-secondary mb-3 btn-sm">← Kembali</a>

                    <table id="example1" class="table table-bordered">
                        <thead>
                            <tr>
                                <th style="text-align: center">No</th>
                                <th style="text-align: center">ID Pelanggan</th>
                                <th style="text-align: center">Nama Pelanggan</th>
                                <th style="text-align: center">Paket</th>
                                <th style="text-align: center">No. WA</th>
                                <th style="text-align: center">Teknisi</th>
                                <th style="text-align: center">Tgl. Aktivasi</th>
                                <th style="text-align: center">Opsi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td style="text-align: center; vertical-align: middle"><?php echo e($loop->iteration); ?></td>
                                    <td style="text-align: center; vertical-align: middle"><?php echo e($customer->id_pelanggan); ?>

                                    </td>
                                    <td><?php echo e($customer->nama_lengkap); ?></td>
                                    <td><?php echo e($customer->paket_internet); ?></td>
                                    <td style="text-align: center">
                                        <a href="https://wa.me/<?php echo e($customer->no_whatsapp); ?>" target="_blank"
                                            class="btn btn-success btn-sm">
                                            <i class="bi bi-whatsapp"></i> <?php echo e($customer->no_whatsapp); ?>

                                        </a>
                                    </td>
                                    <td><?php echo e(App\Models\User::find($customer->id_teknisi)->nama_lengkap ?? 'N/A'); ?></td>
                                    <td style="text-align: center; vertical-align: middle">
                                        <?php echo e(\Carbon\Carbon::parse($customer->created_at)->format('d-m-Y')); ?></td>
                                    <td style="text-align: center; vertical-align: middle">
                                        <button type="button" class="btn btn-sm btn-info detail-po-btn"
                                            data-bs-toggle="modal" data-bs-target="#poDetailModal" 
                                            data-customer-id="<?php echo e($customer->id_pelanggan); ?>"
                                            data-pppoe-user="<?php echo e($customer->pppoe_username); ?>"
                                            data-pppoe-pass="<?php echo e($customer->pppoe_password); ?>"
                                            data-jenis-modem="<?php echo e($customer->jenis_modem); ?>"
                                            data-sn-perangkat="<?php echo e($customer->sn_perangkat); ?>"
                                            data-pembayaran="<?php echo e($customer->pembayaran); ?>"
                                            data-teknisi-nama="<?php echo e(App\Models\User::find($customer->id_teknisi)->nama_lengkap ?? 'N/A'); ?>"
                                            data-tgl-aktivasi="<?php echo e(\Carbon\Carbon::parse($customer->created_at)->format('d-m-Y')); ?>"
                                             
                                            data-po-paket="<?php echo e($customer->paket_internet); ?>"
                                            data-po-sales="<?php echo e(App\Models\User::find($customer->id_sales)->nama_lengkap ?? 'N/A'); ?>"
                                            data-po-nik="<?php echo e($customer->preOrder->no_identitas ?? 'N/A'); ?>"
                                            data-po-email="<?php echo e($customer->preOrder->alamat_email ?? 'N/A'); ?>"
                                            data-po-alamat="<?php echo e($customer->alamat_lengkap); ?>"
                                            data-po-wa="<?php echo e($customer->no_whatsapp); ?>"
                                            data-po-tgl-po="<?php echo e(\Carbon\Carbon::parse($customer->preOrder->created_at ?? $customer->created_at)->format('d-m-Y')); ?>"
                                            data-po-tikor="<?php echo e($customer->preOrder->titik_koordinat ?? 'N/A'); ?>"
                                            
                                            data-foto-petugas="<?php echo e(asset('storage/' . $customer->foto_petugas)); ?>"
                                            data-foto-terpasang="<?php echo e(asset('storage/' . $customer->foto_terpasang)); ?>"
                                            data-foto-speedtest="<?php echo e(asset('storage/' . $customer->foto_speedtest)); ?>">
                                            <i class="bi bi-search"></i> Detail
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="modal fade" id="poDetailModal" tabindex="-1" aria-labelledby="poDetailModalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog modal-xl">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="poDetailModalLabel">Detail Pelanggan: <span
                                        id="detail_nama_pelanggan"></span></h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <h6><i class="bi bi-info-circle-fill"></i> Data Pelanggan & PO</h6>
                                        <table class="table table-sm table-borderless">
                                            <tr>
                                                <th>Nama Sales</th>
                                                <td id="detail_sales"></td>
                                            </tr>
                                            <tr>
                                                <th>Tgl. Pre-Order</th>
                                                <td id="detail_tgl_po"></td>
                                            </tr>
                                            <tr>
                                                <th>No. Identitas (NIK)</th>
                                                <td id="detail_nik"></td>
                                            </tr>
                                            <tr>
                                                <th>Alamat Email</th>
                                                <td id="detail_email"></td>
                                            </tr>
                                            <tr>
                                                <th>No. WhatsApp</th>
                                                <td id="detail_wa"></td>
                                            </tr>
                                            <tr>
                                                <th>Alamat Lengkap</th>
                                                <td id="detail_alamat_lengkap"></td>
                                            </tr>
                                            <tr>
                                                <th>Titik Koordinat</th>
                                                <td id="detail_tikor">
                                                    <a id="detail_tikor_link" href="#" target="_blank"
                                                        class="btn btn-sm btn-primary ms-2"><i
                                                            class="bi bi-geo-alt-fill"></i> Lihat di Map</a>
                                                </td>
                                            </tr>
                                        </table>
                                    </div>

                                    <div class="col-md-6">
                                        <h6><i class="bi bi-tools"></i> Data Aktivasi & Teknis</h6>
                                        <table class="table table-sm table-borderless">
                                            <tr>
                                                <th>ID Pelanggan</th>
                                                <td id="detail_customer_id"></td>
                                            </tr>
                                            <tr>
                                                <th>Paket Internet</th>
                                                <td id="detail_paket"></td>
                                            </tr>
                                            <tr>
                                                <th>PPPoE Username</th>
                                                <td id="detail_pppoe_user"></td>
                                            </tr>
                                            <tr>
                                                <th>PPPoE Password</th>
                                                <td id="detail_pppoe_pass"></td>
                                            </tr>
                                            <tr>
                                                <th>Jenis Modem</th>
                                                <td id="detail_jenis_modem"></td>
                                            </tr>
                                            <tr>
                                                <th>SN Perangkat</th>
                                                <td id="detail_sn"></td>
                                            </tr>
                                            <tr>
                                                <th>Metode Pembayaran</th>
                                                <td id="detail_pembayaran"></td>
                                            </tr>
                                            <tr>
                                                <th>Partner Teknisi</th>
                                                <td id="detail_partner"></td>
                                            </tr>
                                            <tr>
                                                <th>Teknisi Aktivasi</th>
                                                <td id="detail_teknisi"></td>
                                            </tr>
                                            <tr>
                                                <th>Tgl. Aktivasi</th>
                                                <td id="detail_tgl_aktivasi"></td>
                                            </tr>
                                        </table>
                                    </div>
                                </div>
                                <hr>

                                <h6><i class="bi bi-camera-fill"></i> Dokumentasi Aktivasi</h6>
                                <div class="row text-center mt-3">
                                    <div class="col-md-4">
                                        <p class="fw-bold">Foto Petugas</p>
                                        <img id="img_petugas" src="" class="img-fluid img-thumbnail"
                                            alt="Foto Petugas">
                                    </div>
                                    <div class="col-md-4">
                                        <p class="fw-bold">Foto Perangkat Terpasang</p>
                                        <img id="img_terpasang" src="" class="img-fluid img-thumbnail"
                                            alt="Foto Terpasang">
                                    </div>
                                    <div class="col-md-4">
                                        <p class="fw-bold">Foto Speedtest</p>
                                        <img id="img_speedtest" src="" class="img-fluid img-thumbnail"
                                            alt="Foto Speedtest">
                                    </div>
                                </div>

                                <h6 class="mt-4"><i class="bi bi-file-text-fill"></i> Keterangan:</h6>
                                <p id="detail_keterangan"></p>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary btn-sm"
                                    data-bs-dismiss="modal">Tutup</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <?php $__env->startSection('Scripts'); ?>
        <script src="<?php echo e(asset('dist/js/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('dist/js/bootstrap.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(asset('dist/js/jquery.dataTables.min.js')); ?>"></script>
        <script src="<?php echo e(asset('dist/js/dataTables.bootstrap4.min.js')); ?>"></script>
        <script src="<?php echo e(asset('dist/js/dataTables.responsive.min.js')); ?>"></script>
        <script src="<?php echo e(asset('dist/js/responsive.bootstrap4.min.js')); ?>"></script>
        <script src="<?php echo e(asset('dist/js/dataTables.buttons.min.js')); ?>"></script>
        <script>
            $(function() {
                $("#example1").DataTable({
                    "responsive": true,
                    "lengthChange": false,
                    "autoWidth": false,
                    "ordering": false,
                });
            });
        </script>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                // Logika untuk Modal Detail Pelanggan (poDetailModal)
                const poDetailModal = document.getElementById('poDetailModal');

                if (poDetailModal) {
                    poDetailModal.addEventListener('show.bs.modal', function(event) {
                        const button = event.relatedTarget;

                        // --- PENGAMBILAN DATA AKTIVASI & TEKNIS ---
                        // Pastikan nama attribute data-XXX di tombol HTML SAMA PERSIS dengan ini!
                        const customerId = button.getAttribute('data-customer-id');
                        const poPaket = button.getAttribute('data-po-paket');
                        const pppoeUser = button.getAttribute('data-pppoe-user');
                        const pppoePass = button.getAttribute('data-pppoe-pass');
                        const jenisModem = button.getAttribute('data-jenis-modem');
                        const snPerangkat = button.getAttribute('data-sn-perangkat');
                        const pembayaran = button.getAttribute('data-pembayaran');
                        const partnerTeknisi = button.getAttribute(
                            'data-partner'); // Asumsi Anda menambahkannya
                        const teknisiNama = button.getAttribute('data-teknisi-nama');
                        const tglAktivasi = button.getAttribute('data-tgl-aktivasi');
                        const keterangan = button.getAttribute('data-keterangan');
                        const poNama = button.closest('tr').querySelector('td:nth-child(4)').textContent;

                        // --- PENGAMBILAN DATA FOTO ---
                        const fotoPetugas = button.getAttribute('data-foto-petugas');
                        const fotoTerpasang = button.getAttribute('data-foto-terpasang');
                        const fotoSpeedtest = button.getAttribute('data-foto-speedtest');

                        // --- PENGAMBILAN DATA PO (untuk kelengkapan) ---
                        const poTikor = button.getAttribute('data-po-tikor');
                        const poSales = button.getAttribute('data-po-sales');
                        const poTglPo = button.getAttribute('data-po-tgl-po');
                        const poNik = button.getAttribute('data-po-nik');
                        const poEmail = button.getAttribute('data-po-email');
                        const poWa = button.getAttribute('data-po-wa');
                        const poAlamat = button.getAttribute('data-po-alamat');

                        // --- PENGISIAN DATA PO & ADMINISTRATIF ---

                        // Judul
                        document.getElementById('detail_nama_pelanggan').textContent = poNama;

                        // Data Pelanggan & PO
                        document.getElementById('detail_sales').textContent = poSales;
                        document.getElementById('detail_tgl_po').textContent = poTglPo;
                        document.getElementById('detail_nik').textContent = poNik;
                        document.getElementById('detail_email').textContent = poEmail;
                        document.getElementById('detail_wa').textContent = poWa;
                        document.getElementById('detail_alamat_lengkap').textContent = poAlamat;

                        // Titik Koordinat
                        const detailTikorEl = document.getElementById('detail_tikor');
                        const tikorLink = document.getElementById('detail_tikor_link');

                        detailTikorEl.textContent = poTikor;
                        if (poTikor && poTikor !== 'N/A') {
                            tikorLink.href = `http://googleusercontent.com/maps.google.com/?q=${poTikor}`;
                            tikorLink.style.display = 'inline-block';
                        } else {
                            tikorLink.style.display = 'none';
                        }

                        // --- PENGISIAN DATA AKTIVASI & TEKNIS ---
                        document.getElementById('detail_customer_id').textContent = customerId;
                        // Paket Internet sudah ada di kolom table, atau ambil dari data-po-paket
                        document.getElementById('detail_paket').textContent = poPaket;
                        document.getElementById('detail_pppoe_user').textContent = pppoeUser;
                        document.getElementById('detail_pppoe_pass').textContent = pppoePass;
                        document.getElementById('detail_jenis_modem').textContent = jenisModem;
                        document.getElementById('detail_sn').textContent = snPerangkat;
                        document.getElementById('detail_pembayaran').textContent = pembayaran;
                        document.getElementById('detail_partner').textContent = partnerTeknisi;
                        document.getElementById('detail_teknisi').textContent = teknisiNama;
                        document.getElementById('detail_tgl_aktivasi').textContent = tglAktivasi;

                        // --- PENGISIAN FOTO ---
                        document.getElementById('img_petugas').src = fotoPetugas;
                        document.getElementById('img_terpasang').src = fotoTerpasang;
                        document.getElementById('img_speedtest').src = fotoSpeedtest;

                        // --- PENGISIAN KETERANGAN ---
                        document.getElementById('detail_keterangan').textContent = keterangan;
                    });
                }
            });
        </script>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH /Users/bbs/Documents/Project/erlangga-net/resources/views/customers/active_list.blade.php ENDPATH**/ ?>