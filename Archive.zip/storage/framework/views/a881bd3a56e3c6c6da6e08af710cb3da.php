<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('Css'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('dist/css/dataTables.bootstrap4.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('dist/css/dataTables.bootstrap4.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('dist/css/responsive.bootstrap4.min.css')); ?>">
    <?php $__env->stopSection(); ?>
    <main class="app-main">
        <div class="app-content">
            <div class="card card-primary">
                <div class="card-header">
                    <h3 class="card-title">Daftar Pre-Order Siap Aktivasi</h3>
                </div>
                <div class="card-body">

                    <button type="button" class="btn btn-primary mb-3 btn-sm" data-bs-toggle="modal"
                        data-bs-target="#activationModal">
                        <i class="bi bi-lightning-charge"></i> Aktivasi PO Baru
                    </button>
                    <a href="<?php echo e(route('dashboards.index')); ?>" class="btn btn-secondary mb-3 btn-sm">← Kembali</a>
                    
                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-sm"><?php echo e(session('success')); ?></div>
                    <?php endif; ?>

                    <?php if(session('error')): ?>
                        <div class="alert alert-danger alert-sm"><?php echo nl2br(e(session('error'))); ?></div>
                    <?php endif; ?>

                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <strong>Ada kesalahan input:</strong>
                            <ul class="mb-0">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($err); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <table id="example1" class="table table-bordered">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Tgl PO</th>
                                <th>Sales</th>
                                <th>Nama</th>
                                <th>Paket</th>
                                <th>Koordinat</th>
                                <th>Opsi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $preOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $po): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($po->created_at)->format('d-m-Y')); ?></td>
                                    <td><?php echo e($po->nama_sales); ?></td>
                                    <td><?php echo e($po->nama_lengkap); ?></td>
                                    <td><?php echo e($po->paket_internet); ?></td>
                                    <td><?php echo e($po->titik_koordinat); ?></td>
                                    <td>
                                        <button type="button" class="btn btn-success btn-sm activate-btn"
                                            data-bs-toggle="modal" data-bs-target="#activationModal"
                                            data-po-id="<?php echo e($po->id); ?>" data-po-sales-id="<?php echo e($po->id_sales); ?>"
                                            data-po-nama="<?php echo e($po->nama_lengkap); ?>"
                                            data-po-paket="<?php echo e($po->paket_internet); ?>">
                                            Aktivasi
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="modal fade" id="activationModal" tabindex="-1" aria-labelledby="activationModalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="activationModalLabel">Formulir Aktivasi Pelanggan</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <form id="activationForm" method="POST" action="<?php echo e(route('customers.store')); ?>"
                                enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="modal-body">
                                    <input type="hidden" id="modal_pre_order_id" name="pre_order_id" required>
                                    <input type="hidden" id="modal_id_sales" name="id_sales" required>
                                    <input type="hidden" name="id_teknisi" value="<?php echo e(auth()->id()); ?>">

                                    <div class="row">
                                        <div class="col-md-6">
                                            <h6 class="text-primary">Data Pre-Order</h6>
                                            <div class="mb-3">
                                                <label for="po_nama_lengkap" class="form-label">Nama Pelanggan
                                                    (PO)</label>
                                                <input type="text" class="form-control" id="po_nama_lengkap"
                                                    readonly>
                                            </div>
                                            <div class="mb-3">
                                                <label for="po_paket" class="form-label">Paket Internet (PO)</label>
                                                <input type="text" class="form-control" id="po_paket" readonly>
                                            </div>
                                            <div class="mb-3">
                                                <label for="partner" class="form-label">Partner / Teknisi Tambahan
                                                    (Opsional)</label>
                                                <input type="text" class="form-control" id="partner" name="partner"
                                                    placeholder="Contoh: Nama rekan teknisi">
                                            </div>
                                            <div class="mb-3">
                                                <label for="keterangan" class="form-label">Keterangan Aktivasi</label>
                                                <textarea class="form-control" id="keterangan" name="keterangan" rows="2"></textarea>
                                            </div>
                                            <h6 class="text-primary mt-4">Dokumentasi Foto</h6>
                                            <div class="mb-3">
                                                <label for="foto_petugas" class="form-label">Foto Petugas (Wajah
                                                    Teknisi)</label>
                                                <input type="file" class="form-control" id="foto_petugas"
                                                    name="foto_petugas" accept="image/*" required>
                                            </div>
                                            <div class="mb-3">
                                                <label for="foto_terpasang" class="form-label">Foto Perangkat
                                                    Terpasang</label>
                                                <input type="file" class="form-control" id="foto_terpasang"
                                                    name="foto_terpasang" accept="image/*" required>
                                            </div>
                                            <div class="mb-3">
                                                <label for="foto_speedtest" class="form-label">Foto Hasil
                                                    Speedtest</label>
                                                <input type="file" class="form-control" id="foto_speedtest"
                                                    name="foto_speedtest" accept="image/*" required>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <h6 class="text-success">Data Teknis & Billing</h6>
                                            <div class="mb-3">
                                                <label for="id_pelanggan" class="form-label">ID Pelanggan
                                                    (Billing)</label>
                                                <input type="text" class="form-control" id="id_pelanggan"
                                                    name="id_pelanggan" required autocomplete="off">
                                            </div>
                                            <div class="mb-3">
                                                <label for="pppoe_username" class="form-label">Akun PPPoE
                                                    (Username)</label>
                                                <input type="text" class="form-control" id="pppoe_username"
                                                    name="pppoe_username" required autocomplete="off">
                                            </div>
                                            <div class="mb-3">
                                                <label for="pppoe_password" class="form-label">Sandi PPPoE</label>
                                                <input type="text" class="form-control" id="pppoe_password"
                                                    name="pppoe_password" required autocomplete="off">
                                            </div>
                                            <div class="mb-3">
                                                <label for="jenis_modem" class="form-label">Jenis Modem</label>
                                                <select class="form-control" id="jenis_modem" name="jenis_modem"
                                                    required>
                                                    <option value="">Pilih Jenis Modem</option>
                                                    <option value="EPON">EPON</option>
                                                    <option value="GPON">GPON</option>
                                                </select>
                                            </div>
                                            <div class="mb-3">
                                                <label for="sn_perangkat" class="form-label">SN Perangkat ONT</label>
                                                <input type="text" class="form-control" id="sn_perangkat"
                                                    name="sn_perangkat" required autocomplete="off">
                                            </div>
                                            <div class="mb-3">
                                                <label for="pembayaran" class="form-label">Metode Pembayaran</label>
                                                <select class="form-control" id="pembayaran" name="pembayaran"
                                                    required>
                                                    <option value="">Pilih Metode</option>
                                                    <option value="Cash">Cash</option>
                                                    <option value="Transfer">Transfer</option>
                                                    <option value="Aplikasi">Aplikasi Pembayaran</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary btn-sm"
                                        data-bs-dismiss="modal">Batal</button>
                                    <button type="submit" class="btn btn-success btn-sm">Aktivasi Pelanggan</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <?php $__env->startSection('Scripts'); ?>
        <script src="<?php echo e(asset('dist/js/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('dist/js/bootstrap.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(asset('dist/js/jquery.dataTables.min.js')); ?>"></script>
        <script src="<?php echo e(asset('dist/js/dataTables.bootstrap4.min.js')); ?>"></script>
        <script src="<?php echo e(asset('dist/js/dataTables.responsive.min.js')); ?>"></script>
        <script src="<?php echo e(asset('dist/js/responsive.bootstrap4.min.js')); ?>"></script>
        <script src="<?php echo e(asset('dist/js/dataTables.buttons.min.js')); ?>"></script>
        <script>
            $(function() {
                $("#example1").DataTable({
                    "responsive": true,
                    "lengthChange": false,
                    "autoWidth": false,
                    "ordering": false,
                });
            });
        </script>
        <script>
            // Listener untuk tombol Aktivasi di tabel
            document.addEventListener('DOMContentLoaded', function() {
                const activationModal = document.getElementById('activationModal');

                if (activationModal) {
                    activationModal.addEventListener('show.bs.modal', function(event) {
                        const button = event.relatedTarget;

                        // Ambil data PO dari tombol
                        const poId = button.getAttribute('data-po-id');
                        const poSalesId = button.getAttribute('data-po-sales-id');
                        const poNama = button.getAttribute('data-po-nama');
                        const poPaket = button.getAttribute('data-po-paket');

                        // Isi hidden field dan field readonly di modal
                        document.getElementById('modal_pre_order_id').value = poId;
                        document.getElementById('modal_id_sales').value = poSalesId;
                        document.getElementById('po_nama_lengkap').value = poNama;
                        document.getElementById('po_paket').value = poPaket;

                        // Reset form input teknis agar tidak ada sisa data lama
                        document.getElementById('id_pelanggan').value = '';
                        document.getElementById('pppoe_username').value = '';
                        document.getElementById('pppoe_password').value = '';
                        document.getElementById('sn_perangkat').value = '';
                        document.getElementById('jenis_modem').selectedIndex = 0;
                        document.getElementById('pembayaran').selectedIndex = 0;
                        document.getElementById('partner').value = '';
                        document.getElementById('keterangan').value = '';
                    });
                }
            });
        </script>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH /Users/bbs/Documents/Project/erlangga-net/resources/views/customers.blade.php ENDPATH**/ ?>