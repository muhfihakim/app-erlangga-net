<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container">
        <h1>Pelacakan Lokasi Pengguna</h1>
        <div class="mb-4">
            <label for="user_selector" class="form-label">Pilih Pengguna:</label>
            <select id="user_selector" class="form-select">
                <option value="">Semua Pengguna</option>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($user->id); ?>"><?php echo e($user->nama_lengkap); ?> - <?php echo e($user->jabatan); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div id="map" style="height: 500px;"></div>
    </div>

    <?php $__env->startSection('scripts'); ?>
        <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
        <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

        <script>
            // Inisialisasi peta dengan koordinat default (Jakarta)
            const map = L.map('map').setView([-6.2088, 106.8456], 13);

            // Menambahkan layer OpenStreetMap
            L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
                maxZoom: 19,
                attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
            }).addTo(map);

            let markers = [];

            // Fungsi untuk menghapus semua marker dari peta
            function clearMarkers() {
                markers.forEach(marker => map.removeLayer(marker));
                markers = [];
            }

            // Fungsi untuk menambahkan marker ke peta berdasarkan data lokasi
            function addMarkers(locations) {
                clearMarkers();

                locations.forEach(location => {
                    const marker = L.marker([location.latitude, location.longitude])
                        .addTo(map)
                        .bindPopup(`<b>${location.nama_lengkap}</b><br>${location.jabatan}`);
                    markers.push(marker);
                });

                // Memperbesar peta agar sesuai dengan semua marker
                if (locations.length > 0) {
                    const group = new L.featureGroup(markers);
                    map.fitBounds(group.getBounds());
                }
            }

            // Tampilkan semua lokasi saat halaman pertama kali dimuat
            const initialLocations = <?php echo json_encode($locations, 15, 512) ?>;
            addMarkers(initialLocations);

            // Event listener untuk dropdown
            const userSelector = document.getElementById('user_selector');
            userSelector.addEventListener('change', function() {
                const userId = this.value;
                let url = '<?php echo e(route('api.locations.all')); ?>';

                if (userId) {
                    url = `/api/locations/${userId}`;
                }

                // Mengambil data lokasi menggunakan Fetch API
                fetch(url)
                    .then(response => response.json())
                    .then(data => {
                        addMarkers(data);
                    })
                    .catch(error => console.error('Error fetching locations:', error));
            });
        </script>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH /Users/bbs/Documents/Project/erlangga-net/resources/views/account-tracking.blade.php ENDPATH**/ ?>