<!--begin::Header-->
<nav class="app-header navbar navbar-expand bg-body">
    <!--begin::Container-->
    <div class="container-fluid">
        <!--begin::Start Navbar Links-->
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" data-lte-toggle="sidebar" href="#" role="button">
                    <i class="bi bi-list"></i>
                </a>
            </li>
            <li class="nav-item d-none d-md-block"><a href="#" class="nav-link">PT. Baraya Bareng Sadulur | BBS
                    Network</a>
            </li>
        </ul>
        <!--end::Start Navbar Links-->
        <!--begin::End Navbar Links-->
        <ul class="navbar-nav ms-auto">
            <!--begin::Notifications Dropdown Menu-->
            
            <!--end::Notifications Dropdown Menu-->
            <!--begin::User Menu Dropdown-->
            <li class="nav-item dropdown user-menu">
                <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                    <img src="<?php echo e(asset('dist/assets/img/Foto Profil.png')); ?>" class="user-image rounded-circle shadow"
                        alt="Logo Pemprov Papua Tengah" />
                    <span class="d-none d-md-inline"><?php echo e(auth()->user()->nama_lengkap ?? 'Pengguna'); ?></span> -
                    <small><?php echo e(auth()->user()->jabatan ?? 'Jabatan'); ?></small>
                </a>
                <ul class="dropdown-menu dropdown-menu-lg dropdown-menu-end">
                    <!--begin::User Image-->
                    <li class="user-header text-bg-primary">
                        <img src="<?php echo e(asset('dist/assets/img/Foto Profil.png')); ?>" class="rounded-circle shadow"
                            alt="Logo Pemprov Papua Tengah" />
                        <p>
                            <?php echo e(auth()->user()->nama_lengkap ?? 'Pengguna'); ?>

                        </p>
                        <small><?php echo e(auth()->user()->jabatan ?? 'Jabatan'); ?></small>
                    </li>
                    <!--end::User Image-->
                    <!--begin::Menu Footer-->
                    <li class="user-footer">
                        
                        <!-- Form Logout -->
                        <form action="<?php echo e(route('logout')); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-default btn-flat float-end">
                                Logout
                            </button>
                        </form>
                    </li>
                    <!--end::Menu Footer-->
                </ul>
            </li>
            <!--end::User Menu Dropdown-->
        </ul>
        <!--end::End Navbar Links-->
    </div>
    <!--end::Container-->
</nav>
<!--end::Header-->
<?php /**PATH /Users/bbs/Documents/Project/erlangga-net v0.1/resources/views/components/layouts/navbar.blade.php ENDPATH**/ ?>