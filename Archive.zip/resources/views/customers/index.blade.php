<x-layouts.app>
    @section('Css')
        <link rel="stylesheet" href="{{ asset('dist/css/dataTables.bootstrap4.min.css') }}">
        <link rel="stylesheet" href="{{ asset('dist/css/dataTables.bootstrap4.min.css') }}">
        <link rel="stylesheet" href="{{ asset('dist/css/responsive.bootstrap4.min.css') }}">
    @endsection
    <main class="app-main">
        <div class="app-content">
            <div class="card card-primary">
                <div class="card-header">
                    <h3 class="card-title">Daftar Pre-Order Siap Aktivasi</h3>
                </div>
                <div class="card-body">
                    @if (Auth::user()->jabatan === 'Administrator')
                        <table id="example1" class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th style="text-align: center">No</th>
                                    <th>Tgl PO</th>
                                    <th>Sales</th>
                                    <th>Nama</th>
                                    <th>Paket</th>
                                    <th>Ditugaskan Kepada</th>
                                    <th>Opsi</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($allPreOrders as $po)
                                    <tr>
                                        <td>{{ $loop->iteration }}</td>
                                        <td>{{ \Carbon\Carbon::parse($po->created_at)->format('d-m-Y') }}</td>
                                        <td>{{ $po->nama_sales }}</td>
                                        <td>{{ $po->nama_lengkap }}</td>
                                        <td>{{ $po->paket_internet }}</td>
                                        <td>
                                            @if ($po->id_teknisi_delegasi)
                                                <span class="badge bg-info">{{ $po->delegated_to }}</span>
                                                <p class="small text-muted mb-0">
                                                    {{ \Carbon\Carbon::parse($po->delegated_at)->format('d/m H:i') }}
                                                </p>
                                            @else
                                                <span class="badge bg-secondary">Belum Ditunjuk</span>
                                            @endif
                                        </td>
                                        <td>
                                            {{-- ... (Tombol Opsi Admin: Delegasikan, Edit, Hapus) ... --}}
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                </div>
            </div>
        @else
            <div class="card card-info">
                <div class="card-header">
                    <h3 class="card-title">1. Tugas Delegasi Khusus (Prioritas)</h3>
                    <p class="float-sm-right text-sm mb-0">Hanya PO yang ditunjuk kepada Anda</p>
                </div>
                <div class="card-body">
                    <table id="delegatedTable" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th style="text-align: center">No</th>
                                <th style="text-align: center">Tgl PO</th>
                                <th style="text-align: center">Sales</th>
                                <th style="text-align: center">Nama</th>
                                <th style="text-align: center">Paket</th>
                                <th style="text-align: center">Status</th>
                                <th style="text-align: center">Deadline</th>
                                <th style="text-align: center">Opsi</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($delegatedTasks as $po)
                                <tr>
                                    <td style="text-align: center; vertical-align: middle">{{ $loop->iteration }}</td>
                                    <td style="text-align: center; vertical-align: middle">
                                        {{ \Carbon\Carbon::parse($po->created_at)->format('d-m-Y') }}</td>
                                    <td style="text-align: center; vertical-align: middle">{{ $po->nama_sales }}</td>
                                    <td style="text-align: center; vertical-align: middle">{{ $po->nama_lengkap }}</td>
                                    <td style="text-align: center; vertical-align: middle">{{ $po->paket_internet }}
                                    </td>

                                    {{-- Kolom Status --}}
                                    <td style="text-align: center; vertical-align: middle">
                                        @if ($po->is_locked)
                                            <span class="badge bg-danger">EXPIRED</span>
                                        @elseif ($po->deadline_status == 'SEGERA')
                                            <span class="badge bg-warning text-dark">SEGERA</span>
                                        @else
                                            <span class="badge bg-success">AKTIF</span>
                                        @endif
                                    </td>

                                    {{-- Kolom Deadline --}}
                                    <td style="text-align: center; vertical-align: middle">
                                        {{ $po->deadline_date ?? '-' }}
                                    </td>

                                    <td style="text-align: center; vertical-align: middle">
                                        {{-- LOGIKA LOCKED STATUS --}}
                                        @if ($po->is_locked)
                                            <button type="button" class="btn btn-danger btn-sm" disabled>
                                                <i class="bi bi-lock-fill"></i> Locked
                                            </button>
                                            <p class="text-danger small mt-1 mb-0" style="font-size: 0.75rem;">Hubungi
                                                Admin</p>
                                        @else
                                            <button type="button" class="btn btn-success btn-sm activate-btn"
                                                data-bs-toggle="modal" data-bs-target="#activationModal"
                                                data-po-id="{{ $po->id }}"
                                                data-po-sales-id="{{ $po->id_sales }}"
                                                data-po-nama="{{ $po->nama_lengkap }}"
                                                data-po-paket="{{ $po->paket_internet }}">
                                                Aktivasi
                                            </button>
                                        @endif
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card card-secondary mt-4">
                <div class="card-header">
                    <h3 class="card-title">2. Tugas Umum</h3>
                    <p class="float-sm-right text-sm mb-0">PO yang belum ditugaskan</p>
                </div>
                <div class="card-body">
                    <table id="generalTable" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th style="text-align: center">No</th>
                                <th style="text-align: center">Tgl PO</th>
                                <th style="text-align: center">Sales</th>
                                <th style="text-align: center">Nama</th>
                                <th style="text-align: center">Paket</th>
                                <th style="text-align: center">Tikor</th>
                                <th style="text-align: center">Opsi</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($generalTasks as $po)
                                <tr>
                                    <td style="text-align: center; vertical-align: middle">{{ $loop->iteration }}</td>
                                    <td style="text-align: center; vertical-align: middle">
                                        {{ \Carbon\Carbon::parse($po->created_at)->format('d-m-Y') }}</td>
                                    <td style="text-align: center; vertical-align: middle">{{ $po->nama_sales }}</td>
                                    <td style="text-align: center; vertical-align: middle">{{ $po->nama_lengkap }}</td>
                                    <td style="text-align: center; vertical-align: middle">{{ $po->paket_internet }}
                                    </td>
                                    <td style="text-align: center; vertical-align: middle">
                                        <a href="https://www.google.com/maps/search/?api=1&query={{ $po->titik_koordinat }}"
                                            target="_blank" class="btn btn-sm btn-info">
                                            <i class="fas fa-map-marker-alt"></i> Lihat Lokasi
                                        </a>
                                    </td>
                                    <td style="text-align: center; vertical-align: middle;">
                                        <button type="button" class="btn btn-success btn-sm activate-btn"
                                            data-bs-toggle="modal" data-bs-target="#activationModal"
                                            data-po-id="{{ $po->id }}" data-po-sales-id="{{ $po->id_sales }}"
                                            data-po-nama="{{ $po->nama_lengkap }}"
                                            data-po-paket="{{ $po->paket_internet }}">
                                            Aktivasi
                                        </button>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
            @endif
        </div>
        <div class="modal fade" id="activationModal" tabindex="-1" aria-labelledby="activationModalLabel"
            aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="activationModalLabel">Formulir Aktivasi Pelanggan</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                            aria-label="Close"></button>
                    </div>
                    <form id="activationForm" method="POST" action="{{ route('customers.store') }}"
                        enctype="multipart/form-data">
                        @csrf
                        <div class="modal-body">
                            <input type="hidden" id="modal_pre_order_id" name="pre_order_id" required>
                            <input type="hidden" id="modal_id_sales" name="id_sales" required>
                            <input type="hidden" name="id_teknisi" value="{{ auth()->id() }}">

                            <div class="row">
                                <div class="col-md-6">
                                    <h6 class="text-primary">Data Pre-Order</h6>
                                    <div class="mb-3">
                                        <label for="po_nama_lengkap" class="form-label">Nama Pelanggan
                                            (PO)</label>
                                        <input type="text" class="form-control" id="po_nama_lengkap" readonly>
                                    </div>
                                    <div class="mb-3">
                                        <label for="po_paket" class="form-label">Paket Internet (PO)</label>
                                        <input type="text" class="form-control" id="po_paket" readonly>
                                    </div>
                                    <div class="mb-3">
                                        <label for="partner" class="form-label">Partner / Teknisi Tambahan
                                            (Opsional)</label>
                                        <input type="text" class="form-control" id="partner" name="partner"
                                            placeholder="Contoh: Nama rekan teknisi">
                                    </div>
                                    <div class="mb-3">
                                        <label for="keterangan" class="form-label">Keterangan Aktivasi</label>
                                        <textarea class="form-control" id="keterangan" name="keterangan" rows="2"></textarea>
                                    </div>
                                    <h6 class="text-primary mt-4">Dokumentasi Foto</h6>
                                    <div class="mb-3">
                                        <label for="foto_petugas" class="form-label">Foto Petugas (Wajah
                                            Teknisi)</label>
                                        <input type="file" class="form-control" id="foto_petugas"
                                            name="foto_petugas" accept="image/*" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="foto_terpasang" class="form-label">Foto Perangkat
                                            Terpasang</label>
                                        <input type="file" class="form-control" id="foto_terpasang"
                                            name="foto_terpasang" accept="image/*" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="foto_speedtest" class="form-label">Foto Hasil
                                            Speedtest</label>
                                        <input type="file" class="form-control" id="foto_speedtest"
                                            name="foto_speedtest" accept="image/*" required>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <h6 class="text-success">Data Teknis & Billing</h6>
                                    <div class="mb-3">
                                        <label for="id_pelanggan" class="form-label">ID Pelanggan
                                            (Billing)</label>
                                        <input type="text" class="form-control" id="id_pelanggan"
                                            name="id_pelanggan" required autocomplete="off">
                                    </div>
                                    <div class="mb-3">
                                        <label for="pppoe_username" class="form-label">Akun PPPoE
                                            (Username)</label>
                                        <input type="text" class="form-control" id="pppoe_username"
                                            name="pppoe_username" required autocomplete="off">
                                    </div>
                                    <div class="mb-3">
                                        <label for="pppoe_password" class="form-label">Sandi PPPoE</label>
                                        <input type="text" class="form-control" id="pppoe_password"
                                            name="pppoe_password" required autocomplete="off">
                                    </div>
                                    <div class="mb-3">
                                        <label for="jenis_modem" class="form-label">Jenis Modem</label>
                                        <select class="form-control" id="jenis_modem" name="jenis_modem" required>
                                            <option value="">Pilih Jenis Modem</option>
                                            <option value="EPON">EPON</option>
                                            <option value="GPON">GPON</option>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label for="sn_perangkat" class="form-label">SN Perangkat ONT</label>
                                        <input type="text" class="form-control" id="sn_perangkat"
                                            name="sn_perangkat" required autocomplete="off">
                                    </div>
                                    <div class="mb-3">
                                        <label for="pembayaran" class="form-label">Metode Pembayaran</label>
                                        <select class="form-control" id="pembayaran" name="pembayaran" required>
                                            <option value="">Pilih Metode</option>
                                            <option value="Cash">Cash</option>
                                            <option value="Transfer">Transfer</option>
                                            <option value="Aplikasi">Aplikasi Pembayaran</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary btn-sm"
                                data-bs-dismiss="modal">Batal</button>
                            <button type="submit" class="btn btn-success btn-sm">Aktivasi Pelanggan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </main>
    @section('Scripts')
        <script src="{{ asset('dist/js/jquery.min.js') }}"></script>
        <script src="{{ asset('dist/js/bootstrap.bundle.min.js') }}"></script>
        <script src="{{ asset('dist/js/jquery.dataTables.min.js') }}"></script>
        <script src="{{ asset('dist/js/dataTables.bootstrap4.min.js') }}"></script>
        <script src="{{ asset('dist/js/dataTables.responsive.min.js') }}"></script>
        <script src="{{ asset('dist/js/responsive.bootstrap4.min.js') }}"></script>
        <script src="{{ asset('dist/js/dataTables.buttons.min.js') }}"></script>
        <script>
            $(function() {
                $("#example1").DataTable({
                    "responsive": true,
                    "lengthChange": false,
                    "autoWidth": false,
                    "ordering": false,
                });
                $("#delegatedTable").DataTable({
                    "responsive": true,
                    "lengthChange": true,
                    "autoWidth": false,
                    "ordering": false,
                });
                $("#generalTable").DataTable({
                    "responsive": true,
                    "lengthChange": true,
                    "autoWidth": false,
                    "ordering": false
                });
            });
        </script>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <script>
            // Logika untuk menampilkan SweetAlert
            @if (session('success'))
                Swal.fire({
                    icon: 'success',
                    title: 'Berhasil!',
                    text: '{{ session('success') }}',
                    showConfirmButton: false,
                    timer: 3000
                });
            @endif

            @if (session('error'))
                Swal.fire({
                    icon: 'error',
                    title: 'Oops...',
                    text: '{{ session('error') }}',
                });
            @endif
        </script>
        <script>
            // Listener untuk tombol Aktivasi di tabel
            document.addEventListener('DOMContentLoaded', function() {
                const activationModal = document.getElementById('activationModal');

                if (activationModal) {
                    activationModal.addEventListener('show.bs.modal', function(event) {
                        const button = event.relatedTarget;

                        // Ambil data PO dari tombol
                        const poId = button.getAttribute('data-po-id');
                        const poSalesId = button.getAttribute('data-po-sales-id');
                        const poNama = button.getAttribute('data-po-nama');
                        const poPaket = button.getAttribute('data-po-paket');

                        // Isi hidden field dan field readonly di modal
                        document.getElementById('modal_pre_order_id').value = poId;
                        document.getElementById('modal_id_sales').value = poSalesId;
                        document.getElementById('po_nama_lengkap').value = poNama;
                        document.getElementById('po_paket').value = poPaket;

                        // Reset form input teknis agar tidak ada sisa data lama
                        document.getElementById('id_pelanggan').value = '';
                        document.getElementById('pppoe_username').value = '';
                        document.getElementById('pppoe_password').value = '';
                        document.getElementById('sn_perangkat').value = '';
                        document.getElementById('jenis_modem').selectedIndex = 0;
                        document.getElementById('pembayaran').selectedIndex = 0;
                        document.getElementById('partner').value = '';
                        document.getElementById('keterangan').value = '';
                    });
                }
            });
        </script>
    @endsection
</x-layouts.app>
